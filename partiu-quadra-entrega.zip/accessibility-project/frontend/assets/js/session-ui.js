import { api, getSession, refreshSession } from "./api.js";
import { initials } from "./format.js";

function isOwner(user) {
  return user?.roles?.includes("OWNER") || user?.roles?.includes("ADMIN");
}

function updateNavigation(user) {
  for (const avatar of document.querySelectorAll("a.avatar")) {
    if (user) {
      avatar.textContent = initials(user.displayName);
      avatar.href = "/pages/perfil/";
      avatar.setAttribute("aria-label", `Abrir perfil de ${user.displayName}`);
      avatar.classList.remove("avatar-login");
    } else {
      avatar.textContent = "Entrar";
      avatar.href = `/pages/login/?next=${encodeURIComponent(window.location.pathname + window.location.search)}`;
      avatar.setAttribute("aria-label", "Entrar na sua conta");
      avatar.classList.add("avatar-login");
    }
  }

  for (const link of document.querySelectorAll("a[href*='painel-proprietario'], a[href*='solicitacoes/'], a[href*='meus-anuncios/'], a[href*='agenda-proprietario/']")) {
    if (!isOwner(user) && !link.closest("[data-owner-always-visible]")) {
      link.classList.add("is-hidden");
    } else {
      link.classList.remove("is-hidden");
    }
  }
}

export async function initializeSessionUi() {
  let session = getSession();
  if (!session) {
    try {
      session = await refreshSession();
    } catch {
      session = null;
    }
  }
  updateNavigation(session?.user || null);
  window.addEventListener("sessionchange", (event) => updateNavigation(event.detail));

  for (const control of document.querySelectorAll("[data-logout]")) {
    control.addEventListener("click", async (event) => {
      event.preventDefault();
      control.setAttribute("aria-busy", "true");
      await api.logout();
      window.location.assign("/pages/inicio/");
    });
  }
}
