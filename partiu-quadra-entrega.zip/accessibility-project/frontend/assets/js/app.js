import { initializeLoginPage, initializeRegisterPage } from "./auth-pages.js";
import {
  initializeCourtPage,
  initializeCreateCourtPage,
  initializeHomePage,
  initializeOwnerCourtsPage,
  initializeSavedCourtsPage,
  initializeSearchPage
} from "./court-pages.js";
import {
  initializeBookingRequestPage,
  initializeCardPaymentPage,
  initializeConfirmationPage,
  initializeCounterResponsePage,
  initializeMyBookingsPage,
  initializePaymentChoicePage,
  initializePixPaymentPage,
  initializeRequestSentPage
} from "./booking-pages.js";
import {
  initializeChallengeProposalPage,
  initializeChallengeResponsePage,
  initializeChallengeTeamPage,
  initializeCreateTeamPage,
  initializeDiscoverTeamsPage,
  initializeInvitationPage,
  initializeInviteMembersPage,
  initializeTeamPage,
  initializeTeamsPage
} from "./team-pages.js";
import { initializeChatPage, initializeMessagesPage } from "./message-pages.js";
import {
  initializeCounterRequestPage,
  initializeOwnerAcceptedPage,
  initializeOwnerAgendaPage,
  initializeOwnerDashboardPage,
  initializeOwnerRequestPage,
  initializeOwnerRequestsPage,
  initializeRejectRequestPage
} from "./owner-pages.js";
import { initializeProfilePage } from "./profile-page.js";
import { initializeSessionUi } from "./session-ui.js";

const pageInitializers = {
  home: initializeHomePage,
  search: initializeSearchPage,
  court: initializeCourtPage,
  savedCourts: initializeSavedCourtsPage,
  ownerCourts: initializeOwnerCourtsPage,
  createCourt: initializeCreateCourtPage,
  bookingRequest: initializeBookingRequestPage,
  requestSent: initializeRequestSentPage,
  myBookings: initializeMyBookingsPage,
  paymentChoice: initializePaymentChoicePage,
  pixPayment: initializePixPaymentPage,
  cardPayment: initializeCardPaymentPage,
  confirmation: initializeConfirmationPage,
  counterResponse: initializeCounterResponsePage,
  teams: initializeTeamsPage,
  createTeam: initializeCreateTeamPage,
  team: initializeTeamPage,
  inviteMembers: initializeInviteMembersPage,
  discoverTeams: initializeDiscoverTeamsPage,
  challengeTeam: initializeChallengeTeamPage,
  invitation: initializeInvitationPage,
  challengeProposal: initializeChallengeProposalPage,
  challengeResponse: initializeChallengeResponsePage,
  messages: initializeMessagesPage,
  chat: initializeChatPage,
  ownerRequests: initializeOwnerRequestsPage,
  ownerRequest: initializeOwnerRequestPage,
  rejectRequest: initializeRejectRequestPage,
  counterRequest: initializeCounterRequestPage,
  ownerAccepted: initializeOwnerAcceptedPage,
  ownerDashboard: initializeOwnerDashboardPage,
  ownerAgenda: initializeOwnerAgendaPage,
  profile: initializeProfilePage,
  login: initializeLoginPage,
  register: initializeRegisterPage
};

const initialize = pageInitializers[document.body.dataset.page];
Promise.resolve(initializeSessionUi())
  .then(() => initialize?.())
  .catch(() => undefined);
