# Backend

API REST do Partiu Quadra em Spring Boot, Spring Security, JPA, PostgreSQL e
Redis Streams.

## Organização

- `controller`: endpoints HTTP;
- `dto`: contratos de entrada e saída;
- `model`: entidades e enums;
- `repository`: acesso ao PostgreSQL;
- `service`: regras de negócio;
- `security`: configuração do Spring Security;
- `worker`: fila Redis e consumidores;
- `integration`: adaptadores de pagamento;
- `config` e `exception`: configuração e erros da API.

## Domínios implementados

- cadastro, login, refresh rotacionado, logout e perfil autenticado;
- papéis `PLAYER`, `OWNER` e `ADMIN`, com permissões por operação;
- cadastro com fotos e estrutura, busca, favoritos e moderação de quadras;
- times, convites, desafios e contrapropostas;
- solicitações de aluguel, resposta do proprietário e reservas;
- pagamentos idempotentes por Pix ou cartão tokenizado;
- conversas de reservas e desafios;
- worker de pagamentos com repetição e fila morta.

## Endereços principais

| Método | Caminho | Acesso |
| --- | --- | --- |
| `POST` | `/api/v1/auth/register` | público |
| `POST` | `/api/v1/auth/login` | público |
| `GET` | `/api/v1/courts` | público |
| `POST` | `/api/v1/courts` | proprietário |
| `POST` | `/api/v1/teams` | autenticado |
| `POST` | `/api/v1/rental-requests` | autenticado |
| `PATCH` | `/api/v1/rental-requests/{id}/accept` | proprietário |
| `POST` | `/api/v1/transactions` | autenticado |
| `POST` | `/api/v1/conversations/{id}/messages` | participante |

O cabeçalho `Idempotency-Key` é obrigatório ao criar uma transação. Para
cartão, `paymentTokenReference` deve ser um token do provedor. A API rejeita
números de cartão enviados diretamente.

## Banco

As migrações ficam em `src/main/resources/db/migration`. O schema `app` é
criado pelo Flyway e não depende do schema público do Supabase. Para conectar
ao Supabase depois, basta trocar as variáveis do datasource e manter SSL
habilitado na URL JDBC.

## Processamento

A API publica o identificador da transação no stream
`transactions:pending`. O worker usa o grupo `transaction-workers`, processa
com bloqueio no registro, confirma a reserva após aprovação e envia falhas
definitivas para `transactions:dead-letter`. Um recuperador republica registros
que ficaram pendentes por indisponibilidade temporária.
