package com.partiuquadra.api.security;

import com.partiuquadra.api.config.JwtProperties;
import com.partiuquadra.api.service.JwtService;
import com.partiuquadra.api.model.PermissionEntity;
import com.partiuquadra.api.model.RoleEntity;
import com.partiuquadra.api.model.UserEntity;

import static org.assertj.core.api.Assertions.assertThat;

import java.time.Duration;
import java.util.UUID;
import javax.crypto.SecretKey;
import org.junit.jupiter.api.Test;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.security.oauth2.jwt.JwtDecoder;
import org.springframework.security.oauth2.jwt.JwtEncoder;
import org.springframework.test.util.ReflectionTestUtils;

class JwtServiceTest {

    @Test
    void issuesSignedTokenWithRolesAndPermissions() {
        JwtProperties properties = new JwtProperties(
                "https://auth.partiuquadra.test",
                "1234567890123456789012345678901234567890123456789012345678901234",
                Duration.ofMinutes(15),
                Duration.ofDays(30));
        SecurityConfig securityConfig = new SecurityConfig();
        SecretKey key = securityConfig.jwtSecretKey(properties);
        JwtEncoder encoder = securityConfig.jwtEncoder(key);
        JwtDecoder decoder = securityConfig.jwtDecoder(key, properties);

        PermissionEntity permission = new PermissionEntity();
        ReflectionTestUtils.setField(permission, "name", "court:read");
        RoleEntity role = new RoleEntity();
        ReflectionTestUtils.setField(role, "name", "PLAYER");
        role.getPermissions().add(permission);
        UserEntity user = new UserEntity();
        UUID userId = UUID.randomUUID();
        ReflectionTestUtils.setField(user, "id", userId);
        user.setUsername("gabriel");
        user.getRoles().add(role);

        String token = new JwtService(encoder, properties).issueAccessToken(user);
        Jwt decoded = decoder.decode(token);

        assertThat(decoded.getSubject()).isEqualTo(userId.toString());
        assertThat(decoded.getIssuer().toString()).isEqualTo("https://auth.partiuquadra.test");
        assertThat(decoded.getClaimAsStringList("authorities"))
                .containsExactly("ROLE_PLAYER", "court:read");
    }
}
