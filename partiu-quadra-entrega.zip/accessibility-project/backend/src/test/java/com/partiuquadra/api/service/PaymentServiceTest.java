package com.partiuquadra.api.service;

import com.partiuquadra.api.exception.ApiException;
import com.partiuquadra.api.dto.PaymentDtos;
import com.partiuquadra.api.model.PaymentMethod;
import com.partiuquadra.api.repository.PaymentTransactionRepository;
import com.partiuquadra.api.model.ReservationEntity;
import com.partiuquadra.api.repository.ReservationRepository;
import com.partiuquadra.api.model.UserEntity;
import com.partiuquadra.api.repository.UserRepository;

import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.util.Optional;
import java.util.UUID;
import org.junit.jupiter.api.Test;
import org.springframework.test.util.ReflectionTestUtils;

class PaymentServiceTest {

    @Test
    void rejectsRawCardData() {
        PaymentTransactionRepository transactions = mock(PaymentTransactionRepository.class);
        ReservationRepository reservations = mock(ReservationRepository.class);
        UserRepository users = mock(UserRepository.class);
        PaymentService service = new PaymentService(transactions, reservations, users);

        UUID payerId = UUID.randomUUID();
        UUID reservationId = UUID.randomUUID();
        UserEntity payer = new UserEntity();
        ReflectionTestUtils.setField(payer, "id", payerId);
        ReservationEntity reservation = new ReservationEntity();
        ReflectionTestUtils.setField(reservation, "id", reservationId);
        reservation.setBookedBy(payer);

        when(transactions.findByPayerIdAndIdempotencyKey(payerId, "idempotency-key-123"))
                .thenReturn(Optional.empty());
        when(reservations.findWithRelationsById(reservationId))
                .thenReturn(Optional.of(reservation));

        PaymentDtos.CreateRequest request = new PaymentDtos.CreateRequest(
                reservationId,
                PaymentMethod.CARD,
                "4111111111111111");

        assertThatThrownBy(() -> service.create(payerId, "idempotency-key-123", request))
                .isInstanceOf(ApiException.class)
                .extracting(exception -> ((ApiException) exception).getCode())
                .isEqualTo("RAW_CARD_DATA_REJECTED");
    }
}
