package com.partiuquadra.api.service;

import com.partiuquadra.api.integration.PaymentGateway;
import com.partiuquadra.api.model.PaymentTransactionEntity;
import com.partiuquadra.api.repository.PaymentTransactionRepository;
import com.partiuquadra.api.model.ReservationEntity;
import com.partiuquadra.api.model.ReservationStatus;
import com.partiuquadra.api.model.TransactionEventEntity;
import com.partiuquadra.api.repository.TransactionEventRepository;
import com.partiuquadra.api.model.TransactionStatus;
import com.partiuquadra.api.config.WorkerProperties;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.Optional;
import java.util.UUID;
import org.junit.jupiter.api.Test;

class TransactionProcessorTest {

    @Test
    void confirmsReservationAfterApprovedCharge() {
        PaymentTransactionRepository transactions = mock(PaymentTransactionRepository.class);
        TransactionEventRepository events = mock(TransactionEventRepository.class);
        PaymentGateway gateway = mock(PaymentGateway.class);
        WorkerProperties properties = new WorkerProperties(
                true,
                "transactions:pending",
                "transaction-workers",
                "worker-test",
                "transactions:dead-letter",
                10,
                5);
        TransactionProcessor processor =
                new TransactionProcessor(transactions, events, gateway, properties);

        UUID transactionId = UUID.randomUUID();
        ReservationEntity reservation = new ReservationEntity();
        PaymentTransactionEntity transaction = new PaymentTransactionEntity();
        transaction.setReservation(reservation);
        transaction.setStatus(TransactionStatus.QUEUED);
        when(transactions.findForProcessing(transactionId))
                .thenReturn(Optional.of(transaction));
        when(gateway.charge(transaction))
                .thenReturn(new PaymentGateway.GatewayResult(
                        PaymentGateway.GatewayOutcome.APPROVED,
                        "mock_reference",
                        null));

        TransactionProcessor.ProcessingResult result = processor.process(transactionId);

        assertThat(result).isEqualTo(TransactionProcessor.ProcessingResult.DONE);
        assertThat(transaction.getStatus()).isEqualTo(TransactionStatus.SUCCEEDED);
        assertThat(reservation.getStatus()).isEqualTo(ReservationStatus.CONFIRMED);
        verify(events, org.mockito.Mockito.times(2)).save(any(TransactionEventEntity.class));
    }
}

