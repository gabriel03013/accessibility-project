package com.partiuquadra.api.service;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.jupiter.api.Test;

class SlugServiceTest {

    private final SlugService slugService = new SlugService();

    @Test
    void createsStableSlugFromPortugueseName() {
        assertThat(slugService.slugify("  Arena São José  "))
                .isEqualTo("arena-sao-jose");
    }
}

