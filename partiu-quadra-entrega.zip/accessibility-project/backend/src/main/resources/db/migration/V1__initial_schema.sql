CREATE EXTENSION IF NOT EXISTS btree_gist;

REVOKE CREATE ON SCHEMA app FROM PUBLIC;

CREATE TABLE users (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    email VARCHAR(254) NOT NULL,
    username VARCHAR(32) NOT NULL,
    password_hash VARCHAR(100) NOT NULL,
    display_name VARCHAR(100) NOT NULL,
    phone VARCHAR(24),
    birth_date DATE,
    avatar_url VARCHAR(500),
    status VARCHAR(20) NOT NULL DEFAULT 'ACTIVE'
        CHECK (status IN ('ACTIVE', 'SUSPENDED', 'DELETED')),
    email_verified BOOLEAN NOT NULL DEFAULT FALSE,
    failed_login_attempts INTEGER NOT NULL DEFAULT 0
        CHECK (failed_login_attempts >= 0),
    locked_until TIMESTAMPTZ,
    last_login_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    deleted_at TIMESTAMPTZ,
    CONSTRAINT users_email_length CHECK (length(email) BETWEEN 5 AND 254),
    CONSTRAINT users_username_format
        CHECK (username ~ '^[a-zA-Z0-9._-]{3,32}$')
);

CREATE UNIQUE INDEX uq_users_email_ci ON users(lower(email));
CREATE UNIQUE INDEX uq_users_username_ci ON users(lower(username));

CREATE TABLE roles (
    id BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    name VARCHAR(40) NOT NULL UNIQUE,
    description VARCHAR(160) NOT NULL
);

CREATE TABLE permissions (
    id BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    name VARCHAR(80) NOT NULL UNIQUE,
    description VARCHAR(180) NOT NULL
);

CREATE TABLE user_roles (
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    role_id BIGINT NOT NULL REFERENCES roles(id) ON DELETE RESTRICT,
    granted_by UUID REFERENCES users(id) ON DELETE SET NULL,
    granted_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    PRIMARY KEY (user_id, role_id)
);

CREATE TABLE role_permissions (
    role_id BIGINT NOT NULL REFERENCES roles(id) ON DELETE CASCADE,
    permission_id BIGINT NOT NULL REFERENCES permissions(id) ON DELETE CASCADE,
    PRIMARY KEY (role_id, permission_id)
);

CREATE TABLE refresh_tokens (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    token_hash CHAR(64) NOT NULL UNIQUE,
    expires_at TIMESTAMPTZ NOT NULL,
    revoked_at TIMESTAMPTZ,
    last_used_at TIMESTAMPTZ,
    user_agent_hash CHAR(64),
    ip_hash CHAR(64),
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    CONSTRAINT refresh_tokens_expiry CHECK (expires_at > created_at)
);

CREATE INDEX idx_refresh_tokens_user_active
    ON refresh_tokens(user_id, expires_at)
    WHERE revoked_at IS NULL;

CREATE TABLE sports (
    id BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    slug VARCHAR(40) NOT NULL UNIQUE,
    name VARCHAR(80) NOT NULL UNIQUE,
    active BOOLEAN NOT NULL DEFAULT TRUE
);

CREATE TABLE teams (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    created_by UUID NOT NULL REFERENCES users(id) ON DELETE RESTRICT,
    name VARCHAR(100) NOT NULL,
    slug VARCHAR(140) NOT NULL,
    description VARCHAR(1000),
    skill_level VARCHAR(20) NOT NULL DEFAULT 'MIXED'
        CHECK (skill_level IN ('BEGINNER', 'INTERMEDIATE', 'ADVANCED', 'MIXED')),
    routine VARCHAR(500),
    max_members SMALLINT NOT NULL DEFAULT 20
        CHECK (max_members BETWEEN 2 AND 100),
    public_profile BOOLEAN NOT NULL DEFAULT TRUE,
    status VARCHAR(20) NOT NULL DEFAULT 'ACTIVE'
        CHECK (status IN ('ACTIVE', 'ARCHIVED', 'SUSPENDED')),
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE UNIQUE INDEX uq_teams_slug_ci ON teams(lower(slug));

CREATE TABLE team_sports (
    team_id UUID NOT NULL REFERENCES teams(id) ON DELETE CASCADE,
    sport_id BIGINT NOT NULL REFERENCES sports(id) ON DELETE RESTRICT,
    PRIMARY KEY (team_id, sport_id)
);

CREATE TABLE team_members (
    team_id UUID NOT NULL REFERENCES teams(id) ON DELETE CASCADE,
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    member_role VARCHAR(20) NOT NULL DEFAULT 'MEMBER'
        CHECK (member_role IN ('ADMIN', 'MEMBER')),
    joined_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    PRIMARY KEY (team_id, user_id)
);

CREATE INDEX idx_team_members_user ON team_members(user_id);

CREATE TABLE team_invitations (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    team_id UUID NOT NULL REFERENCES teams(id) ON DELETE CASCADE,
    invited_user_id UUID REFERENCES users(id) ON DELETE CASCADE,
    invited_username VARCHAR(32) NOT NULL,
    invited_by UUID NOT NULL REFERENCES users(id) ON DELETE RESTRICT,
    message VARCHAR(500),
    token_hash CHAR(64) NOT NULL UNIQUE,
    status VARCHAR(20) NOT NULL DEFAULT 'PENDING'
        CHECK (status IN ('PENDING', 'ACCEPTED', 'DECLINED', 'EXPIRED', 'CANCELLED')),
    expires_at TIMESTAMPTZ NOT NULL,
    responded_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    CONSTRAINT team_invitation_expiry CHECK (expires_at > created_at)
);

CREATE UNIQUE INDEX uq_pending_team_invitation
    ON team_invitations(team_id, lower(invited_username))
    WHERE status = 'PENDING';

CREATE TABLE team_challenges (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    challenger_team_id UUID NOT NULL REFERENCES teams(id) ON DELETE CASCADE,
    challenged_team_id UUID NOT NULL REFERENCES teams(id) ON DELETE CASCADE,
    sport_id BIGINT NOT NULL REFERENCES sports(id) ON DELETE RESTRICT,
    created_by UUID NOT NULL REFERENCES users(id) ON DELETE RESTRICT,
    message VARCHAR(1000),
    status VARCHAR(24) NOT NULL DEFAULT 'PENDING'
        CHECK (status IN ('PENDING', 'NEGOTIATING', 'ACCEPTED', 'DECLINED', 'CANCELLED', 'EXPIRED')),
    expires_at TIMESTAMPTZ NOT NULL,
    accepted_proposal_id UUID,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    CONSTRAINT different_challenge_teams CHECK (challenger_team_id <> challenged_team_id)
);

CREATE TABLE challenge_proposals (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    challenge_id UUID NOT NULL REFERENCES team_challenges(id) ON DELETE CASCADE,
    proposed_by_team_id UUID NOT NULL REFERENCES teams(id) ON DELETE CASCADE,
    court_id UUID,
    starts_at TIMESTAMPTZ NOT NULL,
    ends_at TIMESTAMPTZ NOT NULL,
    message VARCHAR(500),
    status VARCHAR(20) NOT NULL DEFAULT 'PENDING'
        CHECK (status IN ('PENDING', 'ACCEPTED', 'REJECTED', 'WITHDRAWN')),
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    CONSTRAINT challenge_proposal_period CHECK (ends_at > starts_at)
);

ALTER TABLE team_challenges
    ADD CONSTRAINT fk_challenge_accepted_proposal
    FOREIGN KEY (accepted_proposal_id) REFERENCES challenge_proposals(id)
    DEFERRABLE INITIALLY DEFERRED;

CREATE TABLE courts (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    owner_id UUID NOT NULL REFERENCES users(id) ON DELETE RESTRICT,
    name VARCHAR(120) NOT NULL,
    slug VARCHAR(160) NOT NULL,
    description VARCHAR(3000) NOT NULL,
    observation VARCHAR(1500),
    address_line VARCHAR(180) NOT NULL,
    address_number VARCHAR(20) NOT NULL,
    address_complement VARCHAR(100),
    neighborhood VARCHAR(100) NOT NULL,
    city VARCHAR(100) NOT NULL,
    state CHAR(2) NOT NULL,
    postal_code VARCHAR(12) NOT NULL,
    latitude NUMERIC(9, 6),
    longitude NUMERIC(9, 6),
    timezone VARCHAR(60) NOT NULL DEFAULT 'America/Sao_Paulo',
    cancellation_policy VARCHAR(1500),
    rules VARCHAR(3000),
    status VARCHAR(24) NOT NULL DEFAULT 'DRAFT'
        CHECK (status IN ('DRAFT', 'PENDING_REVIEW', 'PUBLISHED', 'SUSPENDED', 'ARCHIVED')),
    average_rating NUMERIC(2, 1) NOT NULL DEFAULT 0
        CHECK (average_rating BETWEEN 0 AND 5),
    review_count INTEGER NOT NULL DEFAULT 0 CHECK (review_count >= 0),
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    published_at TIMESTAMPTZ,
    deleted_at TIMESTAMPTZ,
    CONSTRAINT court_coordinates_pair
        CHECK ((latitude IS NULL AND longitude IS NULL)
            OR (latitude BETWEEN -90 AND 90 AND longitude BETWEEN -180 AND 180))
);

CREATE UNIQUE INDEX uq_courts_slug_ci ON courts(lower(slug));

ALTER TABLE challenge_proposals
    ADD CONSTRAINT fk_challenge_proposal_court
    FOREIGN KEY (court_id) REFERENCES courts(id) ON DELETE SET NULL;

CREATE INDEX idx_courts_search
    ON courts(city, state, status);
CREATE INDEX idx_courts_owner
    ON courts(owner_id, status);

CREATE TABLE court_photos (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    court_id UUID NOT NULL REFERENCES courts(id) ON DELETE CASCADE,
    storage_key VARCHAR(500) NOT NULL,
    public_url VARCHAR(1000) NOT NULL,
    alt_text VARCHAR(180) NOT NULL,
    sort_order SMALLINT NOT NULL DEFAULT 0 CHECK (sort_order >= 0),
    is_cover BOOLEAN NOT NULL DEFAULT FALSE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE (court_id, storage_key)
);

CREATE UNIQUE INDEX uq_court_cover_photo
    ON court_photos(court_id)
    WHERE is_cover = TRUE;

CREATE TABLE amenities (
    id BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    slug VARCHAR(60) NOT NULL UNIQUE,
    name VARCHAR(100) NOT NULL UNIQUE
);

CREATE TABLE court_amenities (
    court_id UUID NOT NULL REFERENCES courts(id) ON DELETE CASCADE,
    amenity_id BIGINT NOT NULL REFERENCES amenities(id) ON DELETE RESTRICT,
    note VARCHAR(200),
    PRIMARY KEY (court_id, amenity_id)
);

CREATE TABLE court_sports (
    court_id UUID NOT NULL REFERENCES courts(id) ON DELETE CASCADE,
    sport_id BIGINT NOT NULL REFERENCES sports(id) ON DELETE RESTRICT,
    price_per_hour NUMERIC(12, 2) NOT NULL CHECK (price_per_hour >= 0),
    min_duration_minutes SMALLINT NOT NULL DEFAULT 60
        CHECK (min_duration_minutes BETWEEN 30 AND 720),
    max_participants SMALLINT CHECK (max_participants BETWEEN 1 AND 200),
    PRIMARY KEY (court_id, sport_id)
);

CREATE TABLE court_availability (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    court_id UUID NOT NULL REFERENCES courts(id) ON DELETE CASCADE,
    day_of_week SMALLINT NOT NULL CHECK (day_of_week BETWEEN 1 AND 7),
    starts_at TIME NOT NULL,
    ends_at TIME NOT NULL,
    price_override NUMERIC(12, 2) CHECK (price_override >= 0),
    active BOOLEAN NOT NULL DEFAULT TRUE,
    CONSTRAINT availability_period CHECK (ends_at > starts_at),
    UNIQUE (court_id, day_of_week, starts_at, ends_at)
);

CREATE TABLE court_blocks (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    court_id UUID NOT NULL REFERENCES courts(id) ON DELETE CASCADE,
    created_by UUID NOT NULL REFERENCES users(id) ON DELETE RESTRICT,
    starts_at TIMESTAMPTZ NOT NULL,
    ends_at TIMESTAMPTZ NOT NULL,
    reason VARCHAR(300),
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    CONSTRAINT court_block_period CHECK (ends_at > starts_at)
);

CREATE INDEX idx_court_blocks_period
    ON court_blocks USING gist (court_id, tstzrange(starts_at, ends_at, '[)'));

CREATE TABLE saved_courts (
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    court_id UUID NOT NULL REFERENCES courts(id) ON DELETE CASCADE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    PRIMARY KEY (user_id, court_id)
);

CREATE TABLE rental_requests (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    court_id UUID NOT NULL REFERENCES courts(id) ON DELETE RESTRICT,
    sport_id BIGINT NOT NULL REFERENCES sports(id) ON DELETE RESTRICT,
    requester_id UUID NOT NULL REFERENCES users(id) ON DELETE RESTRICT,
    team_id UUID REFERENCES teams(id) ON DELETE SET NULL,
    requested_starts_at TIMESTAMPTZ NOT NULL,
    requested_ends_at TIMESTAMPTZ NOT NULL,
    participants SMALLINT NOT NULL CHECK (participants BETWEEN 1 AND 200),
    message VARCHAR(1000),
    quoted_amount NUMERIC(12, 2) NOT NULL CHECK (quoted_amount >= 0),
    currency CHAR(3) NOT NULL DEFAULT 'BRL',
    status VARCHAR(28) NOT NULL DEFAULT 'PENDING'
        CHECK (status IN ('PENDING', 'COUNTER_PROPOSED', 'ACCEPTED', 'REJECTED',
                          'CANCELLED', 'EXPIRED')),
    expires_at TIMESTAMPTZ NOT NULL,
    responded_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    CONSTRAINT rental_request_period CHECK (requested_ends_at > requested_starts_at),
    CONSTRAINT rental_request_expiry CHECK (expires_at > created_at)
);

CREATE INDEX idx_rental_requests_requester
    ON rental_requests(requester_id, status, created_at DESC);
CREATE INDEX idx_rental_requests_court
    ON rental_requests(court_id, status, requested_starts_at);

CREATE TABLE rental_request_proposals (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    rental_request_id UUID NOT NULL REFERENCES rental_requests(id) ON DELETE CASCADE,
    proposed_by UUID NOT NULL REFERENCES users(id) ON DELETE RESTRICT,
    starts_at TIMESTAMPTZ NOT NULL,
    ends_at TIMESTAMPTZ NOT NULL,
    amount NUMERIC(12, 2) NOT NULL CHECK (amount >= 0),
    message VARCHAR(500),
    status VARCHAR(20) NOT NULL DEFAULT 'PENDING'
        CHECK (status IN ('PENDING', 'ACCEPTED', 'REJECTED', 'WITHDRAWN')),
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    CONSTRAINT rental_proposal_period CHECK (ends_at > starts_at)
);

CREATE TABLE rental_request_events (
    id BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    rental_request_id UUID NOT NULL REFERENCES rental_requests(id) ON DELETE CASCADE,
    actor_id UUID REFERENCES users(id) ON DELETE SET NULL,
    event_type VARCHAR(40) NOT NULL,
    from_status VARCHAR(28),
    to_status VARCHAR(28),
    metadata JSONB NOT NULL DEFAULT '{}'::jsonb,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE reservations (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    rental_request_id UUID NOT NULL UNIQUE REFERENCES rental_requests(id) ON DELETE RESTRICT,
    court_id UUID NOT NULL REFERENCES courts(id) ON DELETE RESTRICT,
    sport_id BIGINT NOT NULL REFERENCES sports(id) ON DELETE RESTRICT,
    booked_by UUID NOT NULL REFERENCES users(id) ON DELETE RESTRICT,
    team_id UUID REFERENCES teams(id) ON DELETE SET NULL,
    confirmation_code VARCHAR(16) NOT NULL UNIQUE,
    starts_at TIMESTAMPTZ NOT NULL,
    ends_at TIMESTAMPTZ NOT NULL,
    amount NUMERIC(12, 2) NOT NULL CHECK (amount >= 0),
    currency CHAR(3) NOT NULL DEFAULT 'BRL',
    status VARCHAR(24) NOT NULL DEFAULT 'AWAITING_PAYMENT'
        CHECK (status IN ('AWAITING_PAYMENT', 'CONFIRMED', 'IN_PROGRESS',
                          'COMPLETED', 'CANCELLED', 'NO_SHOW')),
    cancelled_by UUID REFERENCES users(id) ON DELETE SET NULL,
    cancellation_reason VARCHAR(500),
    cancelled_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    CONSTRAINT reservation_period CHECK (ends_at > starts_at)
);

ALTER TABLE reservations
    ADD CONSTRAINT no_overlapping_reservations
    EXCLUDE USING gist (
        court_id WITH =,
        tstzrange(starts_at, ends_at, '[)') WITH &&
    )
    WHERE (status IN ('AWAITING_PAYMENT', 'CONFIRMED', 'IN_PROGRESS'));

CREATE INDEX idx_reservations_user
    ON reservations(booked_by, starts_at DESC);
CREATE INDEX idx_reservations_court
    ON reservations(court_id, starts_at);

CREATE TABLE payment_transactions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    reservation_id UUID NOT NULL REFERENCES reservations(id) ON DELETE RESTRICT,
    payer_id UUID NOT NULL REFERENCES users(id) ON DELETE RESTRICT,
    idempotency_key VARCHAR(100) NOT NULL,
    transaction_type VARCHAR(16) NOT NULL DEFAULT 'CHARGE'
        CHECK (transaction_type IN ('CHARGE', 'REFUND')),
    payment_method VARCHAR(16) NOT NULL
        CHECK (payment_method IN ('PIX', 'CARD')),
    payment_token_reference VARCHAR(200),
    provider VARCHAR(40) NOT NULL DEFAULT 'LOCAL_MOCK',
    provider_reference VARCHAR(160),
    amount NUMERIC(12, 2) NOT NULL CHECK (amount > 0),
    currency CHAR(3) NOT NULL DEFAULT 'BRL',
    status VARCHAR(20) NOT NULL DEFAULT 'PENDING'
        CHECK (status IN ('PENDING', 'QUEUED', 'PROCESSING', 'SUCCEEDED',
                          'FAILED', 'CANCELLED', 'REFUNDED')),
    attempts SMALLINT NOT NULL DEFAULT 0 CHECK (attempts >= 0),
    last_error_code VARCHAR(80),
    queued_at TIMESTAMPTZ,
    processing_started_at TIMESTAMPTZ,
    processed_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE (payer_id, idempotency_key)
);

CREATE INDEX idx_transactions_worker
    ON payment_transactions(status, created_at)
    WHERE status IN ('PENDING', 'QUEUED', 'PROCESSING');

CREATE TABLE transaction_events (
    id BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    transaction_id UUID NOT NULL REFERENCES payment_transactions(id) ON DELETE CASCADE,
    event_type VARCHAR(40) NOT NULL,
    from_status VARCHAR(20),
    to_status VARCHAR(20),
    details JSONB NOT NULL DEFAULT '{}'::jsonb,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE conversations (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    conversation_type VARCHAR(24) NOT NULL
        CHECK (conversation_type IN ('COURT_BOOKING', 'TEAM_CHALLENGE', 'SUPPORT')),
    court_id UUID REFERENCES courts(id) ON DELETE SET NULL,
    rental_request_id UUID REFERENCES rental_requests(id) ON DELETE SET NULL,
    challenge_id UUID REFERENCES team_challenges(id) ON DELETE SET NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE conversation_participants (
    conversation_id UUID NOT NULL REFERENCES conversations(id) ON DELETE CASCADE,
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    joined_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    last_read_at TIMESTAMPTZ,
    muted BOOLEAN NOT NULL DEFAULT FALSE,
    PRIMARY KEY (conversation_id, user_id)
);

CREATE INDEX idx_conversation_participant_user
    ON conversation_participants(user_id, last_read_at);

CREATE TABLE messages (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    conversation_id UUID NOT NULL REFERENCES conversations(id) ON DELETE CASCADE,
    sender_id UUID NOT NULL REFERENCES users(id) ON DELETE RESTRICT,
    body VARCHAR(4000) NOT NULL,
    sent_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    edited_at TIMESTAMPTZ,
    deleted_at TIMESTAMPTZ,
    CONSTRAINT message_body_not_blank CHECK (length(btrim(body)) > 0)
);

CREATE INDEX idx_messages_conversation
    ON messages(conversation_id, sent_at DESC);

CREATE TABLE reviews (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    reservation_id UUID NOT NULL UNIQUE REFERENCES reservations(id) ON DELETE RESTRICT,
    court_id UUID NOT NULL REFERENCES courts(id) ON DELETE CASCADE,
    author_id UUID NOT NULL REFERENCES users(id) ON DELETE RESTRICT,
    rating SMALLINT NOT NULL CHECK (rating BETWEEN 1 AND 5),
    comment VARCHAR(2000),
    owner_response VARCHAR(2000),
    responded_at TIMESTAMPTZ,
    status VARCHAR(20) NOT NULL DEFAULT 'PUBLISHED'
        CHECK (status IN ('PUBLISHED', 'HIDDEN', 'FLAGGED')),
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX idx_reviews_court
    ON reviews(court_id, status, created_at DESC);

CREATE TABLE notifications (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    notification_type VARCHAR(50) NOT NULL,
    title VARCHAR(160) NOT NULL,
    body VARCHAR(500) NOT NULL,
    action_url VARCHAR(500),
    read_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX idx_notifications_user_unread
    ON notifications(user_id, created_at DESC)
    WHERE read_at IS NULL;

CREATE TABLE audit_logs (
    id BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    actor_id UUID REFERENCES users(id) ON DELETE SET NULL,
    action VARCHAR(80) NOT NULL,
    resource_type VARCHAR(80) NOT NULL,
    resource_id VARCHAR(100),
    ip_hash CHAR(64),
    user_agent_hash CHAR(64),
    metadata JSONB NOT NULL DEFAULT '{}'::jsonb,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX idx_audit_logs_resource
    ON audit_logs(resource_type, resource_id, created_at DESC);
CREATE INDEX idx_audit_logs_actor
    ON audit_logs(actor_id, created_at DESC);

CREATE OR REPLACE FUNCTION touch_updated_at()
RETURNS TRIGGER
LANGUAGE plpgsql
AS $$
BEGIN
    NEW.updated_at = now();
    RETURN NEW;
END;
$$;

CREATE TRIGGER trg_users_updated_at
    BEFORE UPDATE ON users
    FOR EACH ROW EXECUTE FUNCTION touch_updated_at();
CREATE TRIGGER trg_teams_updated_at
    BEFORE UPDATE ON teams
    FOR EACH ROW EXECUTE FUNCTION touch_updated_at();
CREATE TRIGGER trg_challenges_updated_at
    BEFORE UPDATE ON team_challenges
    FOR EACH ROW EXECUTE FUNCTION touch_updated_at();
CREATE TRIGGER trg_courts_updated_at
    BEFORE UPDATE ON courts
    FOR EACH ROW EXECUTE FUNCTION touch_updated_at();
CREATE TRIGGER trg_rental_requests_updated_at
    BEFORE UPDATE ON rental_requests
    FOR EACH ROW EXECUTE FUNCTION touch_updated_at();
CREATE TRIGGER trg_reservations_updated_at
    BEFORE UPDATE ON reservations
    FOR EACH ROW EXECUTE FUNCTION touch_updated_at();
CREATE TRIGGER trg_transactions_updated_at
    BEFORE UPDATE ON payment_transactions
    FOR EACH ROW EXECUTE FUNCTION touch_updated_at();
CREATE TRIGGER trg_conversations_updated_at
    BEFORE UPDATE ON conversations
    FOR EACH ROW EXECUTE FUNCTION touch_updated_at();
CREATE TRIGGER trg_reviews_updated_at
    BEFORE UPDATE ON reviews
    FOR EACH ROW EXECUTE FUNCTION touch_updated_at();
