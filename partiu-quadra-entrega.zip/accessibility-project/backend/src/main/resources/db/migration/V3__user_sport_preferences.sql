CREATE TABLE user_favorite_sports (
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    sport_id BIGINT NOT NULL REFERENCES sports(id) ON DELETE RESTRICT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    PRIMARY KEY (user_id, sport_id)
);

CREATE INDEX idx_user_favorite_sports_sport
    ON user_favorite_sports(sport_id);
