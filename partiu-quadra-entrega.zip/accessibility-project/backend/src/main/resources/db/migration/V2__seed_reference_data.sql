INSERT INTO roles (name, description) VALUES
    ('PLAYER', 'Pessoa que busca quadras, participa de times e faz reservas'),
    ('OWNER', 'Proprietário autorizado a cadastrar e administrar quadras'),
    ('ADMIN', 'Administrador da plataforma com privilégios de moderação');

INSERT INTO permissions (name, description) VALUES
    ('court:read', 'Consultar quadras publicadas'),
    ('court:create', 'Cadastrar uma quadra própria'),
    ('court:update:own', 'Editar uma quadra própria'),
    ('court:moderate', 'Moderar qualquer quadra'),
    ('team:manage', 'Criar times, convidar membros e negociar desafios'),
    ('booking:create', 'Solicitar uma reserva'),
    ('booking:manage:own', 'Responder solicitações das próprias quadras'),
    ('payment:create', 'Iniciar pagamento de uma reserva própria'),
    ('payment:refund', 'Autorizar estornos'),
    ('message:write', 'Enviar mensagens em conversas das quais participa'),
    ('admin:access', 'Acessar operações administrativas');

INSERT INTO role_permissions (role_id, permission_id)
SELECT r.id, p.id
FROM roles r
JOIN permissions p ON p.name IN (
    'court:read', 'team:manage', 'booking:create', 'payment:create', 'message:write'
)
WHERE r.name = 'PLAYER';

INSERT INTO role_permissions (role_id, permission_id)
SELECT r.id, p.id
FROM roles r
JOIN permissions p ON p.name IN (
    'court:read', 'court:create', 'court:update:own', 'team:manage',
    'booking:create', 'booking:manage:own', 'payment:create', 'message:write'
)
WHERE r.name = 'OWNER';

INSERT INTO role_permissions (role_id, permission_id)
SELECT r.id, p.id
FROM roles r
CROSS JOIN permissions p
WHERE r.name = 'ADMIN';

INSERT INTO sports (slug, name) VALUES
    ('futebol', 'Futebol'),
    ('futsal', 'Futsal'),
    ('volei', 'Vôlei'),
    ('basquete', 'Basquete'),
    ('tenis', 'Tênis'),
    ('beach-tennis', 'Beach tennis'),
    ('futevolei', 'Futevôlei'),
    ('padel', 'Padel'),
    ('handebol', 'Handebol');

INSERT INTO amenities (slug, name) VALUES
    ('estacionamento', 'Estacionamento'),
    ('vestiario', 'Vestiário'),
    ('chuveiro', 'Chuveiro'),
    ('iluminacao', 'Iluminação noturna'),
    ('arquibancada', 'Arquibancada'),
    ('wifi', 'Wi-Fi'),
    ('acessibilidade', 'Acesso para cadeira de rodas'),
    ('bebedouro', 'Bebedouro'),
    ('coletes', 'Coletes'),
    ('bola', 'Bola disponível'),
    ('churrasqueira', 'Churrasqueira');

