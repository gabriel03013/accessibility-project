INSERT INTO amenities (slug, name) VALUES
    ('banheiro-acessivel', 'Banheiro acessível'),
    ('coberta', 'Quadra coberta')
ON CONFLICT (slug) DO NOTHING;
