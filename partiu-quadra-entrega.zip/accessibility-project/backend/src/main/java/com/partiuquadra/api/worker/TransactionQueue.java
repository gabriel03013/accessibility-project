package com.partiuquadra.api.worker;

import java.util.UUID;

public interface TransactionQueue {

    void enqueue(UUID transactionId);
}

