package com.partiuquadra.api.worker;

import com.partiuquadra.api.service.TransactionProcessor;
import com.partiuquadra.api.config.WorkerProperties;

import jakarta.annotation.PostConstruct;
import java.time.Duration;
import java.time.Instant;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.dao.DataAccessException;
import org.springframework.data.redis.connection.stream.Consumer;
import org.springframework.data.redis.connection.stream.MapRecord;
import org.springframework.data.redis.connection.stream.ReadOffset;
import org.springframework.data.redis.connection.stream.StreamOffset;
import org.springframework.data.redis.connection.stream.StreamReadOptions;
import org.springframework.data.redis.connection.stream.StreamRecords;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

@Component
@ConditionalOnProperty(name = "app.worker.enabled", havingValue = "true")
public class TransactionWorker {

    private static final Logger LOGGER = LoggerFactory.getLogger(TransactionWorker.class);

    private final StringRedisTemplate redis;
    private final WorkerProperties properties;
    private final TransactionProcessor processor;
    private final TransactionQueue queue;

    public TransactionWorker(
            StringRedisTemplate redis,
            WorkerProperties properties,
            TransactionProcessor processor,
            TransactionQueue queue) {
        this.redis = redis;
        this.properties = properties;
        this.processor = processor;
        this.queue = queue;
    }

    @PostConstruct
    void initializeGroup() {
        try {
            redis.opsForStream().createGroup(
                    properties.stream(),
                    ReadOffset.from("0-0"),
                    properties.group());
        } catch (DataAccessException exception) {
            String message = exception.getMessage();
            if (message == null || !message.contains("BUSYGROUP")) {
                throw exception;
            }
        }
    }

    @Scheduled(fixedDelayString = "${app.worker.poll-delay-ms:1000}")
    @SuppressWarnings("unchecked")
    void consume() {
        List<MapRecord<String, Object, Object>> records = redis.opsForStream().read(
                Consumer.from(properties.group(), properties.consumerName()),
                StreamReadOptions.empty().count(properties.batchSize()),
                StreamOffset.create(properties.stream(), ReadOffset.from("0-0")));
        if (records == null || records.isEmpty()) {
            records = redis.opsForStream().read(
                Consumer.from(properties.group(), properties.consumerName()),
                StreamReadOptions.empty()
                        .count(properties.batchSize())
                        .block(Duration.ofSeconds(2)),
                StreamOffset.create(properties.stream(), ReadOffset.lastConsumed()));
        }
        if (records == null) {
            return;
        }
        for (MapRecord<String, Object, Object> record : records) {
            handle(record);
        }
    }

    private void handle(MapRecord<String, Object, Object> record) {
        Object rawId = record.getValue().get("transactionId");
        if (rawId == null) {
            acknowledge(record);
            return;
        }
        try {
            UUID transactionId = UUID.fromString(rawId.toString());
            TransactionProcessor.ProcessingResult result = processor.process(transactionId);
            acknowledge(record);
            if (result == TransactionProcessor.ProcessingResult.RETRY) {
                queue.enqueue(transactionId);
            } else if (result == TransactionProcessor.ProcessingResult.DEAD_LETTER) {
                deadLetter(transactionId, "PROCESSING_FAILED");
            }
        } catch (RuntimeException exception) {
            LOGGER.error("Transaction record {} failed", record.getId(), exception);
        }
    }

    private void acknowledge(MapRecord<String, Object, Object> record) {
        redis.opsForStream().acknowledge(
                properties.stream(),
                properties.group(),
                record.getId());
    }

    private void deadLetter(UUID transactionId, String reason) {
        MapRecord<String, String, String> record = StreamRecords
                .mapBacked(Map.of(
                        "transactionId", transactionId.toString(),
                        "reason", reason,
                        "failedAt", Instant.now().toString()))
                .withStreamKey(properties.deadLetterStream());
        redis.opsForStream().add(record);
    }
}
