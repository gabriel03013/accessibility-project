package com.partiuquadra.api.dto;

import com.partiuquadra.api.model.PaymentMethod;
import com.partiuquadra.api.model.TransactionStatus;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import java.math.BigDecimal;
import java.time.Instant;
import java.util.UUID;

public final class PaymentDtos {

    private PaymentDtos() {
    }

    public record CreateRequest(
            @NotNull UUID reservationId,
            @NotNull PaymentMethod paymentMethod,
            @Size(max = 200) String paymentTokenReference) {
    }

    public record TransactionView(
            UUID id,
            UUID reservationId,
            String courtName,
            PaymentMethod paymentMethod,
            BigDecimal amount,
            String currency,
            TransactionStatus status,
            short attempts,
            Instant queuedAt,
            Instant processedAt,
            Instant createdAt) {
    }
}

