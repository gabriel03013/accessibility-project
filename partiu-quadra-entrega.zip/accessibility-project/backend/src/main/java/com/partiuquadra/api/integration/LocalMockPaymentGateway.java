package com.partiuquadra.api.integration;

import com.partiuquadra.api.model.PaymentTransactionEntity;

import java.util.UUID;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Component;

@Component
@ConditionalOnProperty(name = "app.payment.mock-enabled", havingValue = "true")
public class LocalMockPaymentGateway implements PaymentGateway {

    @Override
    public GatewayResult charge(PaymentTransactionEntity transaction) {
        String token = transaction.getPaymentTokenReference();
        if ("mock_declined".equals(token)) {
            return new GatewayResult(GatewayOutcome.DECLINED, null, "PAYMENT_DECLINED");
        }
        if ("mock_retry".equals(token)) {
            return new GatewayResult(GatewayOutcome.RETRYABLE_FAILURE, null, "PROVIDER_UNAVAILABLE");
        }
        return new GatewayResult(
                GatewayOutcome.APPROVED,
                "mock_" + UUID.randomUUID(),
                null);
    }
}

