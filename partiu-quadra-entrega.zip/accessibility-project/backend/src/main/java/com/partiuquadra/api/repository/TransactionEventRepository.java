package com.partiuquadra.api.repository;

import com.partiuquadra.api.model.TransactionEventEntity;

import org.springframework.data.jpa.repository.JpaRepository;

public interface TransactionEventRepository extends JpaRepository<TransactionEventEntity, Long> {
}

