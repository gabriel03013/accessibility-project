package com.partiuquadra.api.service;

import com.partiuquadra.api.exception.ApiException;
import com.partiuquadra.api.config.AppSecurityProperties;

import java.time.Duration;
import java.util.Locale;
import org.springframework.dao.DataAccessException;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;

@Component
public class LoginRateLimiter {

    private final StringRedisTemplate redis;
    private final AppSecurityProperties properties;
    private final TokenFingerprintService fingerprints;

    public LoginRateLimiter(
            StringRedisTemplate redis,
            AppSecurityProperties properties,
            TokenFingerprintService fingerprints) {
        this.redis = redis;
        this.properties = properties;
        this.fingerprints = fingerprints;
    }

    public void assertAllowed(String identifier, String ipAddress) {
        try {
            String value = redis.opsForValue().get(key(identifier, ipAddress));
            if (value != null && Long.parseLong(value) >= properties.loginLimit()) {
                throw new ApiException(
                        HttpStatus.TOO_MANY_REQUESTS,
                        "LOGIN_RATE_LIMITED",
                        "Muitas tentativas. Aguarde alguns minutos e tente novamente.");
            }
        } catch (DataAccessException exception) {
            throw new ApiException(
                    HttpStatus.SERVICE_UNAVAILABLE,
                    "AUTH_TEMPORARILY_UNAVAILABLE",
                    "O acesso está temporariamente indisponível.");
        }
    }

    public void registerFailure(String identifier, String ipAddress) {
        try {
            String key = key(identifier, ipAddress);
            Long attempts = redis.opsForValue().increment(key);
            if (attempts != null && attempts == 1) {
                redis.expire(key, properties.loginWindow());
            }
        } catch (DataAccessException exception) {
            throw new ApiException(
                    HttpStatus.SERVICE_UNAVAILABLE,
                    "AUTH_TEMPORARILY_UNAVAILABLE",
                    "O acesso está temporariamente indisponível.");
        }
    }

    public void clear(String identifier, String ipAddress) {
        try {
            redis.delete(key(identifier, ipAddress));
        } catch (DataAccessException ignored) {
        }
    }

    private String key(String identifier, String ipAddress) {
        String source = identifier.toLowerCase(Locale.ROOT).trim() + "|" + ipAddress;
        return "auth:login:" + fingerprints.privateHash(source);
    }
}

