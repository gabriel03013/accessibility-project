package com.partiuquadra.api.worker;

import com.partiuquadra.api.repository.PaymentTransactionRepository;

import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.UUID;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.data.domain.PageRequest;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

@Component
@ConditionalOnProperty(name = "app.worker.enabled", havingValue = "true")
public class TransactionRecoveryPublisher {

    private final PaymentTransactionRepository transactions;
    private final TransactionQueue queue;

    public TransactionRecoveryPublisher(
            PaymentTransactionRepository transactions,
            TransactionQueue queue) {
        this.transactions = transactions;
        this.queue = queue;
    }

    @Scheduled(
            initialDelayString = "${app.worker.recovery-initial-delay-ms:30000}",
            fixedDelayString = "${app.worker.recovery-delay-ms:60000}")
    void recover() {
        transactions.findRecoverableIds(
                        Instant.now().minus(2, ChronoUnit.MINUTES),
                        PageRequest.of(0, 100))
                .forEach(queue::enqueue);
    }
}

