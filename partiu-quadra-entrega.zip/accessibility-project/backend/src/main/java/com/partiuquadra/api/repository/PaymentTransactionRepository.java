package com.partiuquadra.api.repository;

import com.partiuquadra.api.model.PaymentTransactionEntity;

import java.util.Optional;
import java.util.UUID;
import org.springframework.data.jpa.repository.EntityGraph;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PaymentTransactionRepository
        extends JpaRepository<PaymentTransactionEntity, UUID> {

    @EntityGraph(attributePaths = {"reservation", "reservation.court", "payer"})
    Optional<PaymentTransactionEntity> findByPayerIdAndIdempotencyKey(
            UUID payerId,
            String idempotencyKey);

    @EntityGraph(attributePaths = {"reservation", "reservation.court", "payer"})
    Optional<PaymentTransactionEntity> findWithRelationsById(UUID id);
}
