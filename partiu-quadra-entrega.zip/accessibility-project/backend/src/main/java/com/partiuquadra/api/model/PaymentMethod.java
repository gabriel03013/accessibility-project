package com.partiuquadra.api.model;

public enum PaymentMethod {
    PIX,
    CARD
}

