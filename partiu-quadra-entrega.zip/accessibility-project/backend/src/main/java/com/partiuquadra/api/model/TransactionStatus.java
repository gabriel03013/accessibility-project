package com.partiuquadra.api.model;

public enum TransactionStatus {
    SUCCEEDED,
    FAILED
}
