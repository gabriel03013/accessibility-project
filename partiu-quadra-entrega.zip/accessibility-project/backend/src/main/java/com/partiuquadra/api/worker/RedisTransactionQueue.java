package com.partiuquadra.api.worker;

import com.partiuquadra.api.repository.PaymentTransactionRepository;
import com.partiuquadra.api.model.TransactionStatus;
import com.partiuquadra.api.config.WorkerProperties;

import java.time.Instant;
import java.util.Map;
import java.util.UUID;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.DataAccessException;
import org.springframework.data.redis.connection.stream.MapRecord;
import org.springframework.data.redis.connection.stream.StreamRecords;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

@Component
public class RedisTransactionQueue implements TransactionQueue {

    private static final Logger LOGGER = LoggerFactory.getLogger(RedisTransactionQueue.class);

    private final StringRedisTemplate redis;
    private final WorkerProperties properties;
    private final PaymentTransactionRepository transactions;

    public RedisTransactionQueue(
            StringRedisTemplate redis,
            WorkerProperties properties,
            PaymentTransactionRepository transactions) {
        this.redis = redis;
        this.properties = properties;
        this.transactions = transactions;
    }

    @Override
    @Transactional
    public void enqueue(UUID transactionId) {
        try {
            MapRecord<String, String, String> record = StreamRecords
                    .mapBacked(Map.of(
                            "transactionId", transactionId.toString(),
                            "enqueuedAt", Instant.now().toString()))
                    .withStreamKey(properties.stream());
            redis.opsForStream().add(record);
            transactions.findById(transactionId).ifPresent(transaction -> {
                if (transaction.getStatus() == TransactionStatus.PENDING
                        || transaction.getStatus() == TransactionStatus.QUEUED
                        || transaction.getStatus() == TransactionStatus.PROCESSING) {
                    transaction.setStatus(TransactionStatus.QUEUED);
                    transaction.setQueuedAt(Instant.now());
                }
            });
        } catch (DataAccessException exception) {
            LOGGER.warn("Transaction {} could not be queued", transactionId);
        }
    }
}

