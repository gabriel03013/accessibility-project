package com.partiuquadra.api.model;

public enum CourtStatus {
    DRAFT,
    PENDING_REVIEW,
    PUBLISHED,
    SUSPENDED,
    ARCHIVED
}

