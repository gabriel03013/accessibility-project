package com.partiuquadra.api.model;

public enum TransactionType {
    CHARGE,
    REFUND
}

