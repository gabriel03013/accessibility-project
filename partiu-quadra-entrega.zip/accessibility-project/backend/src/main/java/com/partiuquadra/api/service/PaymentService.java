package com.partiuquadra.api.service;

import com.partiuquadra.api.exception.ApiException;
import com.partiuquadra.api.dto.PaymentDtos;
import com.partiuquadra.api.model.PaymentMethod;
import com.partiuquadra.api.model.PaymentTransactionEntity;
import com.partiuquadra.api.model.TransactionStatus;
import com.partiuquadra.api.repository.PaymentTransactionRepository;
import com.partiuquadra.api.model.ReservationEntity;
import com.partiuquadra.api.repository.ReservationRepository;
import com.partiuquadra.api.model.ReservationStatus;
import com.partiuquadra.api.repository.UserRepository;

import java.time.Instant;
import java.util.UUID;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class PaymentService {

    private final PaymentTransactionRepository transactions;
    private final ReservationRepository reservations;
    private final UserRepository users;

    public PaymentService(
            PaymentTransactionRepository transactions,
            ReservationRepository reservations,
            UserRepository users) {
        this.transactions = transactions;
        this.reservations = reservations;
        this.users = users;
    }

    @Transactional
    public PaymentDtos.TransactionView create(
            UUID payerId,
            String idempotencyKey,
            PaymentDtos.CreateRequest request) {
        String normalizedKey = idempotencyKey == null ? "" : idempotencyKey.trim();
        if (normalizedKey.length() < 16 || normalizedKey.length() > 100) {
            throw new ApiException(
                    HttpStatus.BAD_REQUEST,
                    "INVALID_IDEMPOTENCY_KEY",
                    "Envie uma chave de idempotência válida.");
        }

        PaymentTransactionEntity existing = transactions
                .findByPayerIdAndIdempotencyKey(payerId, normalizedKey)
                .orElse(null);
        if (existing != null) {
            if (!existing.getReservation().getId().equals(request.reservationId())
                    || existing.getPaymentMethod() != request.paymentMethod()) {
                throw new ApiException(
                        HttpStatus.CONFLICT,
                        "IDEMPOTENCY_KEY_REUSED",
                        "Esta chave de idempotência já foi usada em outro pagamento.");
            }
            return toView(existing);
        }

        ReservationEntity reservation = reservations.findWithRelationsById(request.reservationId())
                .orElseThrow(() -> notFound("Reserva não encontrada."));
        if (!reservation.getBookedBy().getId().equals(payerId)) {
            throw new ApiException(
                    HttpStatus.FORBIDDEN,
                    "PAYMENT_FORBIDDEN",
                    "Você não pode pagar esta reserva.");
        }
        if (reservation.getStatus() != ReservationStatus.AWAITING_PAYMENT) {
            throw new ApiException(
                    HttpStatus.CONFLICT,
                    "RESERVATION_NOT_PAYABLE",
                    "Esta reserva não está disponível para pagamento.");
        }
        validateTokenReference(request);

        PaymentTransactionEntity transaction = new PaymentTransactionEntity();
        transaction.setReservation(reservation);
        transaction.setPayer(users.getReferenceById(payerId));
        transaction.setIdempotencyKey(normalizedKey);
        transaction.setPaymentMethod(request.paymentMethod());
        transaction.setPaymentTokenReference(trimToNull(request.paymentTokenReference()));
        transaction.setAmount(reservation.getAmount());
        transaction.setAttempts((short) 1);
        transaction.setProcessedAt(Instant.now());

        if ("mock_declined".equalsIgnoreCase(transaction.getPaymentTokenReference())) {
            transaction.setStatus(TransactionStatus.FAILED);
        } else {
            transaction.setStatus(TransactionStatus.SUCCEEDED);
            reservation.setStatus(ReservationStatus.CONFIRMED);
        }

        transactions.saveAndFlush(transaction);
        return toView(transaction);
    }

    @Transactional(readOnly = true)
    public PaymentDtos.TransactionView get(UUID payerId, UUID transactionId) {
        PaymentTransactionEntity transaction = transactions.findWithRelationsById(transactionId)
                .orElseThrow(() -> notFound("Pagamento não encontrado."));
        if (!transaction.getPayer().getId().equals(payerId)) {
            throw new ApiException(
                    HttpStatus.FORBIDDEN,
                    "PAYMENT_FORBIDDEN",
                    "Você não pode consultar este pagamento.");
        }
        return toView(transaction);
    }

    private void validateTokenReference(PaymentDtos.CreateRequest request) {
        String token = trimToNull(request.paymentTokenReference());
        if (request.paymentMethod() == PaymentMethod.CARD && token == null) {
            throw new ApiException(
                    HttpStatus.BAD_REQUEST,
                    "CARD_TOKEN_REQUIRED",
                    "Use o token seguro gerado pelo provedor do cartão.");
        }
        if (token != null && token.matches("\\d{12,19}")) {
            throw new ApiException(
                    HttpStatus.BAD_REQUEST,
                    "RAW_CARD_DATA_REJECTED",
                    "Os dados do cartão devem ser tokenizados antes do envio.");
        }
    }

    private PaymentDtos.TransactionView toView(PaymentTransactionEntity transaction) {
        return new PaymentDtos.TransactionView(
                transaction.getId(),
                transaction.getReservation().getId(),
                transaction.getReservation().getCourt().getName(),
                transaction.getPaymentMethod(),
                transaction.getAmount(),
                transaction.getCurrency(),
                transaction.getStatus(),
                transaction.getAttempts(),
                null,
                transaction.getProcessedAt(),
                transaction.getCreatedAt());
    }

    private String trimToNull(String value) {
        return value == null || value.isBlank() ? null : value.trim();
    }

    private ApiException notFound(String message) {
        return new ApiException(HttpStatus.NOT_FOUND, "PAYMENT_NOT_FOUND", message);
    }
}
