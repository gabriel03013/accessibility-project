package com.partiuquadra.api.integration;

import com.partiuquadra.api.model.PaymentTransactionEntity;

public interface PaymentGateway {

    GatewayResult charge(PaymentTransactionEntity transaction);

    record GatewayResult(
            GatewayOutcome outcome,
            String providerReference,
            String errorCode) {
    }

    enum GatewayOutcome {
        APPROVED,
        DECLINED,
        RETRYABLE_FAILURE
    }
}

