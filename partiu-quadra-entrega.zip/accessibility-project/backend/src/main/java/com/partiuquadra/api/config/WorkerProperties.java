package com.partiuquadra.api.config;

import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.validation.annotation.Validated;

@Validated
@ConfigurationProperties(prefix = "app.worker")
public record WorkerProperties(
        boolean enabled,
        @NotBlank String stream,
        @NotBlank String group,
        @NotBlank String consumerName,
        @NotBlank String deadLetterStream,
        @Min(1) @Max(100) int batchSize,
        @Min(1) @Max(20) int maxAttempts) {
}

