package com.partiuquadra.api.integration;

import com.partiuquadra.api.model.PaymentTransactionEntity;

import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Component;

@Component
@ConditionalOnProperty(name = "app.payment.mock-enabled", havingValue = "false")
public class DisabledPaymentGateway implements PaymentGateway {

    @Override
    public GatewayResult charge(PaymentTransactionEntity transaction) {
        return new GatewayResult(
                GatewayOutcome.RETRYABLE_FAILURE,
                null,
                "PAYMENT_PROVIDER_NOT_CONFIGURED");
    }
}

