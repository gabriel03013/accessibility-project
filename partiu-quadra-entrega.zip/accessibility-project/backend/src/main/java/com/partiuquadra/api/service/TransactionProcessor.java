package com.partiuquadra.api.service;

import com.partiuquadra.api.integration.PaymentGateway;
import com.partiuquadra.api.model.PaymentTransactionEntity;
import com.partiuquadra.api.repository.PaymentTransactionRepository;
import com.partiuquadra.api.model.ReservationStatus;
import com.partiuquadra.api.model.TransactionEventEntity;
import com.partiuquadra.api.repository.TransactionEventRepository;
import com.partiuquadra.api.model.TransactionStatus;
import com.partiuquadra.api.config.WorkerProperties;

import java.time.Instant;
import java.util.UUID;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class TransactionProcessor {

    private final PaymentTransactionRepository transactions;
    private final TransactionEventRepository events;
    private final PaymentGateway paymentGateway;
    private final WorkerProperties properties;

    public TransactionProcessor(
            PaymentTransactionRepository transactions,
            TransactionEventRepository events,
            PaymentGateway paymentGateway,
            WorkerProperties properties) {
        this.transactions = transactions;
        this.events = events;
        this.paymentGateway = paymentGateway;
        this.properties = properties;
    }

    @Transactional
    public ProcessingResult process(UUID transactionId) {
        PaymentTransactionEntity transaction = transactions.findForProcessing(transactionId)
                .orElse(null);
        if (transaction == null) {
            return ProcessingResult.DONE;
        }
        if (transaction.getStatus() == TransactionStatus.SUCCEEDED
                || transaction.getStatus() == TransactionStatus.FAILED
                || transaction.getStatus() == TransactionStatus.CANCELLED
                || transaction.getStatus() == TransactionStatus.REFUNDED) {
            return ProcessingResult.DONE;
        }

        TransactionStatus previousStatus = transaction.getStatus();
        short attempts = (short) (transaction.getAttempts() + 1);
        transaction.setAttempts(attempts);
        transaction.setStatus(TransactionStatus.PROCESSING);
        transaction.setProcessingStartedAt(Instant.now());
        addEvent(transaction, "PROCESSING_STARTED", previousStatus, TransactionStatus.PROCESSING);

        PaymentGateway.GatewayResult result = paymentGateway.charge(transaction);
        return switch (result.outcome()) {
            case APPROVED -> approve(transaction, result);
            case DECLINED -> decline(transaction, result);
            case RETRYABLE_FAILURE -> retry(transaction, result);
        };
    }

    private ProcessingResult approve(
            PaymentTransactionEntity transaction,
            PaymentGateway.GatewayResult result) {
        transaction.setStatus(TransactionStatus.SUCCEEDED);
        transaction.setProviderReference(result.providerReference());
        transaction.setLastErrorCode(null);
        transaction.setProcessedAt(Instant.now());
        transaction.getReservation().setStatus(ReservationStatus.CONFIRMED);
        addEvent(
                transaction,
                "PAYMENT_SUCCEEDED",
                TransactionStatus.PROCESSING,
                TransactionStatus.SUCCEEDED);
        return ProcessingResult.DONE;
    }

    private ProcessingResult decline(
            PaymentTransactionEntity transaction,
            PaymentGateway.GatewayResult result) {
        transaction.setStatus(TransactionStatus.FAILED);
        transaction.setLastErrorCode(result.errorCode());
        transaction.setProcessedAt(Instant.now());
        addEvent(
                transaction,
                "PAYMENT_DECLINED",
                TransactionStatus.PROCESSING,
                TransactionStatus.FAILED);
        return ProcessingResult.DEAD_LETTER;
    }

    private ProcessingResult retry(
            PaymentTransactionEntity transaction,
            PaymentGateway.GatewayResult result) {
        transaction.setLastErrorCode(result.errorCode());
        if (transaction.getAttempts() >= properties.maxAttempts()) {
            transaction.setStatus(TransactionStatus.FAILED);
            transaction.setProcessedAt(Instant.now());
            addEvent(
                    transaction,
                    "RETRIES_EXHAUSTED",
                    TransactionStatus.PROCESSING,
                    TransactionStatus.FAILED);
            return ProcessingResult.DEAD_LETTER;
        }
        transaction.setStatus(TransactionStatus.QUEUED);
        addEvent(
                transaction,
                "RETRY_SCHEDULED",
                TransactionStatus.PROCESSING,
                TransactionStatus.QUEUED);
        return ProcessingResult.RETRY;
    }

    private void addEvent(
            PaymentTransactionEntity transaction,
            String eventType,
            TransactionStatus from,
            TransactionStatus to) {
        TransactionEventEntity event = new TransactionEventEntity();
        event.setTransaction(transaction);
        event.setEventType(eventType);
        event.setFromStatus(from.name());
        event.setToStatus(to.name());
        events.save(event);
    }

    public enum ProcessingResult {
        DONE,
        RETRY,
        DEAD_LETTER
    }
}

